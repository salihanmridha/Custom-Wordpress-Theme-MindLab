<?php
//all code for custom theme option's parent/general page
function mindlab_admin_create_page(){
  require_once 'template/mindlab-general-page.php';
}


//all code for custom theme option's our services page
function mindlab_our_service_create_page(){
  require_once 'template/mindlab-our-services-page.php';
}
