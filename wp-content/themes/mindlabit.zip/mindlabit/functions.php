<?php
//all style file and script files included
require get_template_directory() . '/inc/function-enqueue.php';
//Mindlab Theme Option admin page
require get_template_directory() . '/inc/function-admin.php';
//Mindlab Theme Supports
require get_template_directory() . '/inc/theme-support.php';
//Mindlab classes for custom widgets
require get_template_directory() . '/inc/mindlab-widgets-class.php';
//Mindlab custom post type
require get_template_directory() . '/inc/mindlab-custom-post-type.php';
//Mindlab custom post type meta boxes
require get_template_directory() . '/inc/custom-team-meta-boxes.php';
//Mindlab custom taxonomies
require get_template_directory() . '/inc/mindlab-custom-taxonomies.php';
//Mindlab theme's ajax handler file
require get_template_directory() . '/inc/mindlab-ajax.php';
